#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
space_health_monitor.py
Astronot sağlığı + kabin telemetrisi için kural tabanlı, trend duyarlı sınıflandırıcı.

Kullanım:
  python space_health_monitor.py classify girdi.csv -o sonuc.csv   # sınıflandır (+ etiket varsa değerlendir)
  python space_health_monitor.py limits   girdi.csv -o limitler.csv # veriden alt/üst limit tahmini

Her ölçüm için çıktı:  LOW / HIGH / OK  +  seviye (NORMAL, CAUTION, WARNING, CRITICAL)
Genel durum = en kötü seviye (+ trend kuralları + birleşik risk kuralı).
NOT: Limitler mühendislik tahminidir; klinik/operasyonel karar için kullanılamaz.
"""
import argparse
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import pandas as pd

LEVELS = ["NORMAL", "CAUTION", "WARNING", "CRITICAL"]


@dataclass(frozen=True)
class Limit:
    """low  = (kritik, uyarı, dikkat): değer bu eşiklerin ALTINA düşerse seviye artar
       high = (dikkat, uyarı, kritik): değer bu eşiklerin ÜSTÜNE çıkarsa seviye artar"""
    low: Optional[Tuple[float, float, float]] = None
    high: Optional[Tuple[float, float, float]] = None
    unit: str = ""


# ---------------------------------------------------------------------------
# 1) LİMİTLER  (istirahat durumu)
# ---------------------------------------------------------------------------
LIMITS_REST = {
    # --- Kabin ortamı ---
    # pCO2: NASA-STD-3001 Vol.2 -> 1 saatlik ort. <= 3.0 mmHg; ISS uçuş kuralı ~4.0;
    #       SMAC (7-180 gün) 5.3 mmHg -> kritik eşiği 5.0 (tahmin, temkinli)
    "pco2": Limit(high=(3.0, 4.0, 5.0), unit="mmHg"),
    # pO2: NASA normoksi ~145-155 mmHg; alt limit ~127 mmHg; yüksek taraf yangın riski
    "po2": Limit(low=(130, 140, 145), high=(165, 175, 190), unit="mmHg"),
    "pressure": Limit(low=(96, 99, 100), high=(103, 105, 110), unit="kPa"),
    # Radyasyon: ISS tipik ~300-800 µSv/gün; ani artış = SPE şüphesi (tahmin)
    "radiation": Limit(high=(450, 600, 1000), unit="uSv/gun"),
    "cabin_temp": Limit(low=(10, 16, 18), high=(27, 30, 35), unit="C"),
    "humidity": Limit(low=(15, 25, 30), high=(60, 70, 85), unit="%"),
    # --- Fizyoloji (klinik aralıklara dayalı tahmin) ---
    "spo2": Limit(low=(92, 94, 95), unit="%"),
    "hr": Limit(low=(40, 45, 50), high=(100, 120, 140), unit="bpm"),
    "hrv": Limit(low=(15, 20, 30), unit="ms"),
    "sys": Limit(low=(80, 90, 100), high=(130, 140, 160), unit="mmHg"),
    "dia": Limit(low=(50, 55, 60), high=(85, 90, 100), unit="mmHg"),
    "core_temp": Limit(low=(35.0, 36.0, 36.4), high=(37.5, 38.0, 39.0), unit="C"),
    "resp": Limit(low=(8, 10, 12), high=(20, 24, 30), unit="/dk"),
}

# Egzersiz sırasında kalp/solunum/tansiyon/ısı beklenen şekilde yükselir -> gevşetilmiş üst limitler.
LIMITS_EXERTION = {
    "hr": Limit(low=(40, 45, 50), high=(155, 170, 185), unit="bpm"),
    "resp": Limit(low=(8, 10, 12), high=(30, 38, 45), unit="/dk"),
    "sys": Limit(low=(80, 90, 100), high=(160, 180, 200), unit="mmHg"),
    "dia": Limit(low=(50, 55, 60), high=(90, 100, 110), unit="mmHg"),
    "core_temp": Limit(low=(35.0, 36.0, 36.4), high=(38.3, 39.0, 40.0), unit="C"),
    "hrv": Limit(unit="ms"),  # egzersizde HRV düşmesi normal -> değerlendirme dışı
}

# Uyku / derin dinlenmede nabız ve solunum doğal olarak düşer -> gevşetilmiş alt limitler.
LIMITS_SLEEP = {
    "hr": Limit(low=(35, 40, 45), high=(100, 120, 140), unit="bpm"),
    "resp": Limit(low=(6, 8, 10), high=(20, 24, 30), unit="/dk"),
}

# Sensör adı -> CSV sütunu
COLS = {
    "pco2": "cabin_pco2_mmhg", "po2": "cabin_po2_mmhg", "pressure": "cabin_pressure_kpa",
    "radiation": "radiation_rate_usv_day", "cabin_temp": "cabin_temp_c",
    "humidity": "relative_humidity_percent",
    "spo2": "spo2_percent", "hr": "heart_rate_bpm", "hrv": "hrv_rmssd_ms",
    "sys": "systolic_bp_mmhg", "dia": "diastolic_bp_mmhg",
    "core_temp": "core_temp_c", "resp": "respiration_rate_bpm",
}
ENV = ["pco2", "po2", "pressure", "radiation", "cabin_temp", "humidity"]
BODY = ["spo2", "hr", "hrv", "sys", "dia", "core_temp", "resp"]

# Fiziksel olarak imkânsız değerler = sensör arızası (analize alınmaz)
PLAUSIBLE = {
    "pco2": (0, 50), "po2": (0, 400), "pressure": (20, 150), "radiation": (0, 1e5),
    "cabin_temp": (-20, 80), "humidity": (0, 100), "spo2": (50, 100), "hr": (20, 250),
    "hrv": (0, 300), "sys": (50, 260), "dia": (30, 160), "core_temp": (30, 43), "resp": (2, 70),
}

# Trend (değişim hızı) kuralları — 15 dakikalık hıza normalize edilir
TREND_PCO2_RISE = 0.5       # mmHg/15dk  -> en az WARNING
TREND_P_DROP_WARN = 1.0     # kPa/15dk   -> en az WARNING (sızıntı şüphesi)
TREND_P_DROP_CRIT = 3.0     # kPa/15dk   -> CRITICAL (hızlı basınç kaybı)
EXERT_HR_MIN = 100          # egzersiz bağlamı için minimum nabız
SLEEP_HR_MAX = 60           # uyku/dinlenme bağlamı: nabız bu değerin altında ...
SLEEP_RR_MAX = 13           # ... ve solunum bu değerin altında (SpO2 >= 94, kabin sakin)
COMPOUND_N = 3              # >=3 sensör aynı anda CAUTION+ ise en az WARNING

ACTIONS = {
    ("pco2", "HIGH"): "CO2 scrubber/CDRA kontrol et, havalandırmayı artır, eforu azalt",
    ("po2", "LOW"): "O2 beslemesini kontrol et, sızıntı olasılığını değerlendir",
    ("po2", "HIGH"): "O2 fazlası: yangın riski, O2 kaynağını kıs",
    ("pressure", "LOW"): "Sızıntı ara, bölmeyi izole et, acil O2 hazırla",
    ("radiation", "HIGH"): "SPE şüphesi: korunaklı bölmeye geç",
    ("spo2", "LOW"): "Hipoksi/hiperkapni olasılığı: kabin gazlarını ve mürettebatı kontrol et",
    ("hrv", "LOW"): "Stres/yorgunluk veya gaz etkisi: mürettebatı izle",
    ("core_temp", "HIGH"): "Isı stresi: soğutmayı artır, dinlendir",
    ("hr", "HIGH"): "Nabız yüksek: efor/stres/hipoksi ayrımını yap",
}


def classify_value(v, lim):
    """Tek bir değer için (yön, seviye) döndürür. yön: LOW / HIGH / OK"""
    if lim.low:
        crit, warn, caut = lim.low
        if v < crit: return "LOW", 3
        if v < warn: return "LOW", 2
        if v < caut: return "LOW", 1
    if lim.high:
        caut, warn, crit = lim.high
        if v > crit: return "HIGH", 3
        if v > warn: return "HIGH", 2
        if v > caut: return "HIGH", 1
    return "OK", 0


def _rate15(cur, prev, dt_min):
    """15 dakikalık değişim hızı; zaman farkı geçersizse None."""
    if dt_min is None or not (0 < dt_min <= 60):
        return None
    return (cur - prev) * 15.0 / dt_min


# ---------------------------------------------------------------------------
# 2) SINIFLANDIRMA
# ---------------------------------------------------------------------------
def _classify_one(g):
    """Tek bir astronotun zaman sıralı verisini sınıflandırır."""
    recs = []
    prev_vals, prev_t, prev_ctx, prev_level = {}, None, "REST", 0

    for _, r in g.iterrows():
        t = r["timestamp"]
        dt = (t - prev_t).total_seconds() / 60 if prev_t is not None else None

        # 2a) Geçerli değerleri ayıkla (eksik / imkânsız değerler dışarıda)
        vals, invalid = {}, []
        for k, col in COLS.items():
            v = r.get(col, np.nan)
            if pd.isna(v):
                continue
            lo, hi = PLAUSIBLE[k]
            if lo <= v <= hi:
                vals[k] = float(v)
            else:
                invalid.append(k)

        # 2b) Kabin ortamı
        env = {k: classify_value(vals[k], LIMITS_REST[k]) for k in ENV if k in vals}
        env_max = max((lv for _, lv in env.values()), default=0)

        # 2c) Trend kuralları
        trend_lvl, notes, trend_actions = 0, [], []

        def rate(k):
            return _rate15(vals[k], prev_vals[k], dt) if (k in vals and k in prev_vals) else None

        d = rate("pco2")
        if d is not None and d >= TREND_PCO2_RISE:
            trend_lvl = max(trend_lvl, 2)
            notes.append(f"pCO2 hizli artis (+{d:.2f} mmHg/15dk)")
            trend_actions.append(ACTIONS[("pco2", "HIGH")])
        d = rate("pressure")
        if d is not None and d <= -TREND_P_DROP_WARN:
            trend_lvl = max(trend_lvl, 3 if d <= -TREND_P_DROP_CRIT else 2)
            notes.append(f"basinc dususu ({d:.2f} kPa/15dk)")
            trend_actions.append(ACTIONS[("pressure", "LOW")])

        # 2d) Bağlam: egzersiz mi? (yüksek nabız + normal SpO2 + kabin tehlikesi yok)
        exertion = (vals.get("hr", 0) >= EXERT_HR_MIN and vals.get("spo2", 0) >= 95
                    and env_max <= 1 and trend_lvl < 2)
        sleeping = (not exertion and vals.get("hr", 999) < SLEEP_HR_MAX and vals.get("resp", 999) < SLEEP_RR_MAX
                    and vals.get("spo2", 0) >= 94 and env_max <= 1 and trend_lvl < 2)
        if exertion:
            ctx, lim = "EXERCISE", {**LIMITS_REST, **LIMITS_EXERTION}
        elif sleeping:
            ctx, lim = "SLEEP", {**LIMITS_REST, **LIMITS_SLEEP}
        else:
            ctx, lim = ("RECOVERY" if prev_ctx == "EXERCISE" else "REST"), LIMITS_REST

        # 2e) Fizyoloji
        body = {k: classify_value(vals[k], lim[k]) for k in BODY if k in vals}
        res = {**env, **body}

        # 2f) Genel seviye
        overall = max(max((lv for _, lv in res.values()), default=0), trend_lvl)
        n_flag = sum(1 for _, lv in res.values() if lv >= 1)
        if n_flag >= COMPOUND_N and overall < 2:
            overall = 2
            notes.append(f"{n_flag} sensor ayni anda sinirda (birlesik risk)")

        flags = [f"{k}:{d_}:{LEVELS[lv]}={vals[k]:g}{LIMITS_REST[k].unit}"
                 for k, (d_, lv) in sorted(res.items(), key=lambda x: -x[1][1]) if lv >= 1]
        actions = list(trend_actions)
        for k, (d_, lv) in res.items():
            a = ACTIONS.get((k, d_))
            if lv == overall and lv >= 1 and a and a not in actions:
                actions.append(a)

        rec = {
            "pred_status": LEVELS[overall],
            "pred_level": overall,
            "pred_context": ctx,
            "pred_recovering": bool(prev_level >= 2 and overall < prev_level),
            "pred_flags": " | ".join(flags),
            "pred_notes": " | ".join(notes),
            "pred_action": " ; ".join(actions[:2]),
            "pred_invalid_sensors": ",".join(invalid),
        }
        for k in COLS:
            rec[f"st_{k}"] = "NA" if k not in vals else (
                "OK" if res[k][0] == "OK" else f"{res[k][0]}/{LEVELS[res[k][1]]}")
        recs.append(rec)

        prev_vals, prev_t, prev_ctx, prev_level = vals, t, ctx, overall

    return pd.concat([g.reset_index(drop=True), pd.DataFrame(recs)], axis=1)


def classify_dataframe(df):
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values(["astronaut_id", "timestamp"]).reset_index(drop=True)
    parts = [_classify_one(g) for _, g in df.groupby("astronaut_id", sort=False)]
    return pd.concat(parts).sort_values(["timestamp", "astronaut_id"]).reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3) DEĞERLENDİRME (risk_status etiketi varsa)
# ---------------------------------------------------------------------------
LABEL_LEVEL = {"NOMINAL": 0, "EXERCISE": 0, "RECOVERY": 0, "RECOVERING": 1, "WARNING": 2, "CRITICAL": 3}


def evaluate(df, show=15):
    if "risk_status" not in df.columns:
        return
    y = df["risk_status"].map(LABEL_LEVEL)
    ok = y.notna()
    y, p = y[ok].astype(int), df.loc[ok, "pred_level"]
    diff = (p - y).abs()
    print(f"\n=== Degerlendirme ({len(y)} satir) ===")
    print(f"Birebir uyum        : {(diff == 0).mean():.1%}")
    print(f"+-1 seviye icinde   : {(diff <= 1).mean():.1%}")
    crit = y == 3
    if crit.any():
        print(f"CRITICAL yakalama   : {(p[crit] == 3).mean():.1%} (>=WARNING: {(p[crit] >= 2).mean():.1%})")
    calm = y == 0
    if calm.any():
        print(f"Yanlis alarm (>=WARNING, etiket sakin): {(p[calm] >= 2).mean():.1%}")
    cm = pd.crosstab(y.map(dict(enumerate(LEVELS))).rename("etiket"),
                     p.map(dict(enumerate(LEVELS))).rename("tahmin"))
    print("\nKarisiklik matrisi:\n", cm)
    bad = df[ok][diff >= 1]
    if len(bad):
        print(f"\nUyusmayan satirlar (ilk {show}):")
        cols = ["timestamp", "astronaut_id", "risk_status", "pred_status", "pred_flags"]
        print(bad[cols].head(show).to_string(index=False))


# ---------------------------------------------------------------------------
# 4) VERİDEN LİMİT TAHMİNİ
# ---------------------------------------------------------------------------
def estimate_limits(df, baseline_status=("NOMINAL",), k=3.0):
    """Sakin (NOMINAL) satırlardan ortalama ± k·std ve yüzdelik limitleri tahmin eder,
    referans limitlerle yan yana koyar."""
    base = df[df["risk_status"].isin(baseline_status)] if "risk_status" in df.columns else df
    rows = []
    for key, col in COLS.items():
        if col not in base.columns:
            continue
        s = pd.to_numeric(base[col], errors="coerce").dropna()
        lo_p, hi_p = PLAUSIBLE[key]
        s = s[(s >= lo_p) & (s <= hi_p)]
        if len(s) < 2:
            continue
        ref = LIMITS_REST[key]
        rows.append({
            "parameter": key, "unit": ref.unit, "n": len(s),
            "mean": s.mean(), "std": s.std(),
            f"est_low(mean-{k:g}sd)": s.mean() - k * s.std(),
            f"est_high(mean+{k:g}sd)": s.mean() + k * s.std(),
            "p01": s.quantile(0.01), "p99": s.quantile(0.99),
            "ref_caution_low": ref.low[2] if ref.low else np.nan,
            "ref_caution_high": ref.high[0] if ref.high else np.nan,
        })
    return pd.DataFrame(rows).round(2)


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("classify", help="telemetriyi sinifla")
    c.add_argument("input"); c.add_argument("-o", "--output", default="classified.csv")
    c.add_argument("--no-eval", action="store_true")
    l = sub.add_parser("limits", help="veriden alt/ust limit tahmini")
    l.add_argument("input"); l.add_argument("-o", "--output", default="estimated_limits.csv")
    l.add_argument("--baseline", nargs="+", default=["NOMINAL"])
    l.add_argument("-k", type=float, default=3.0)
    a = ap.parse_args()

    df = pd.read_csv(a.input)
    if a.cmd == "classify":
        out = classify_dataframe(df)
        out.to_csv(a.output, index=False)
        print(f"{len(out)} satir siniflandi -> {a.output}")
        print(out["pred_status"].value_counts().reindex(LEVELS).fillna(0).astype(int).to_string())
        if not a.no_eval:
            evaluate(out)
    else:
        res = estimate_limits(df, tuple(a.baseline), a.k)
        n = int(res["n"].min()) if len(res) else 0
        if n < 30:
            print(f"UYARI: en az {n} sakin satir var; <30 ornekle std/yuzdelik guvenilmez. Daha fazla veri kullanin.")
        res.to_csv(a.output, index=False)
        print(res.to_string(index=False))
        print(f"\n-> {a.output}")


if __name__ == "__main__":
    main()
