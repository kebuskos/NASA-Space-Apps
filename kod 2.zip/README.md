# Astronaut Health & Cabin Telemetry Monitor

NASA Space Apps Challenge 2026 — *Create Health Monitoring Software for Astronauts on Space Missions*.

The challenge asks for software that gathers health indicators and lets astronauts **evaluate and act on** their own health status
during long missions, where the main hazards are space radiation, isolation and confinement, altered gravity and a closed
environment (immune changes, bone loss, cardiovascular events, behavioral health problems).

This prototype reads crew physiology, cabin environment, radiation and daily check-ins, labels every value **LOW / HIGH / OK** with a
severity (`NORMAL → CAUTION → WARNING → CRITICAL`), rolls them up into risk domains, and tells the crew **why it matters** and **what to do**.

> **Read first:** all crew data here is **synthetic** (individual astronaut records are privacy-protected). Only limits marked **[NASA]**
> trace to NASA documents; everything else is an engineering estimate. This is a prototype, not a medical or flight-certified system.

## Coverage of the challenge

| Challenge hazard / outcome | Indicators in this project | Status |
|---|---|---|
| Closed environment | pCO₂, pO₂, pressure, cabin temp, humidity; trend rules (CO₂ rise, leak) | Covered |
| Space radiation | dose rate, cumulative dose vs 600 mSv career limit; optional live DONKI SEP events | Covered (dose rate simulated) |
| Cardiovascular events | HR, HRV, BP, SpO₂, respiration, core temp, exercise/sleep-aware limits, personal baseline | Covered |
| Behavioral health (isolation) | daily sleep, mood, stress; 3-day streak and compound rules | Covered (self-report, simulated) |
| Bone loss | resistive-exercise minutes as the countermeasure-adherence proxy | Partial (no bone-density data) |
| Immune changes | — | **Not covered** (needs lab data, e.g. NASA OSDR blood panels) |
| Astronaut can "evaluate and act" | per-domain status, plain-language *why it matters* + *suggested steps* (EN/TR), runs offline, replay slider | Covered |

## Quick start

```bash
pip install -r requirements.txt

python src/generate_dataset.py --crew 4 --days 3 --seed 42 -o data/full_telemetry.csv --daily-output data/daily_checkins.csv
python src/space_health_monitor.py classify data/full_telemetry.csv -o data/full_classified.csv
python src/space_health_monitor.py daily data/daily_checkins.csv --telemetry data/full_classified.csv -o data/daily_classified.csv
streamlit run app.py
```

Optional real NASA data (needs internet): `python src/real_data.py --donki 2026-09-15 2026-11-13` (solar particle events, window ≤ 60 days)
and `python src/real_data.py --osdr "bone loss"` (OSDR study search). `python src/real_data.py --selftest` checks the parsers offline.

```
app.py                         Streamlit dashboard (English / Türkçe, replay slider, risk-domain tiles)
src/space_health_monitor.py    classifier, domains, personal baseline, daily rules, evaluation
src/generate_dataset.py        synthetic crew telemetry + daily check-ins
src/real_data.py               optional DONKI SEP / OSDR helpers
data/                          full_telemetry, full_classified, daily_checkins, daily_classified, sample_20rows*
```

## Methodology

### Telemetry algorithm (5-minute data)
1. **Validity:** missing or physically impossible readings (e.g. SpO₂ = 0, pCO₂ = 99) are excluded and reported.
2. **Per-sensor limits:** direction (LOW/HIGH/OK) + level 0–3 from caution / warning / critical thresholds.
3. **Trend rules** (normalised to 15 min): pCO₂ rise ≥ 0.5 mmHg → at least WARNING; pressure drop ≥ 1 kPa → WARNING, ≥ 3 kPa → CRITICAL. They fire before absolute limits are crossed.
4. **Context:** high HR with normal SpO₂ in a calm cabin → `EXERCISE` (relaxed HR/RR/BP/temperature limits, HRV ignored); low HR and RR with normal SpO₂ → `SLEEP` (relaxed lower limits).
5. **Personal baseline:** each astronaut's own median/MAD (first 24 h, calm rows, per context) for HR, HRV, SpO₂, respiration; ≥ 2 indicators ≥ 4 robust-z in the bad direction → CAUTION. Targets the challenge's "recognise changes in themselves".
6. **Compound risk:** ≥ 3 sensors at CAUTION or worse → at least WARNING.
7. **Domains:** environment, radiation, cardio-respiratory levels are reported separately; overall status = worst of them.
8. **Cumulative dose:** dose rate integrated over time, shown against the 600 mSv career limit.

### Daily check-in rules
Sleep, mood, stress and resistive-exercise minutes are scored against estimated limits. Three consecutive days at CAUTION or worse raise the level by one;
two or more behavioral indicators at CAUTION or worse → at least WARNING. A headache is CAUTION, and WARNING when that day's maximum pCO₂ exceeded 3.0 mmHg.

### Thresholds

| Parameter | Caution / Warning / Critical | Basis |
|---|---|---|
| Cabin pCO₂ (high) | > 3.0 / > 4.0 / > 5.0 mmHg | **[NASA]** 3.0 = 1-h average limit, NASA-STD-3001 Vol. 2 [V2 6004]. 4.0 = ISS operational limit in use since 2010; crews reported symptoms from ~2.3 mmHg. 5.0 = conservative value just under the 5.3 mmHg SMAC (7–180 days). |
| Cabin ppO₂ (low) | < 145 / < 140 / < 135 mmHg | **[NASA]** normoxia PIO₂ 145–155 mmHg, mild-hypoxia lower limit 127 mmHg (Vol. 2 Rev B). PIO₂ = (PB − 47)·FIO₂, so 127 mmHg PIO₂ ≈ 135 mmHg cabin ppO₂ at 760 mmHg (used as a proxy). |
| Radiation, cumulative | reference 600 mSv | **[NASA]** career effective dose < 600 mSv (NASA-STD-3001 Vol. 1 [V1 4030]); design reference solar particle event < 250 mSv (V1 4031). |
| Radiation, dose rate | > 450 / > 600 / > 1000 µSv/day | Estimate. For scale: NASA's GCR design ceiling in free space is 1.3 mSv/day. |
| ppO₂ (high), pressure, SpO₂, HR, RR, BP, HRV, core temp, cabin temp, humidity | see `LIMITS_REST` | Estimates (clinical / habitability ranges); exercise and sleep variants in `LIMITS_EXERTION` / `LIMITS_SLEEP`. |
| Daily sleep / mood / stress / resistive exercise | < 6 h / < 2.5 / > 3.5 / < 20 min (caution) | Estimates. |

### Sources
- NASA-STD-3001 Vol. 2: https://www.nasa.gov/reference/6-0-natural-and-induced-environments-vol-2
- Law & Alexander, ISS CO₂ and crew symptoms, NTRS 20150019624: https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/20150019624.pdf
- CO₂ cognition study citing SMAC 10 mmHg / 24 h and 5.3 mmHg / 7–180 d, NTRS 20150021777: https://ntrs.nasa.gov/citations/20150021777
- Inspired O₂ ranges, Vol. 2 Rev B: https://ntrs.nasa.gov/api/citations/20220019130/downloads/SKC%20EVA%20Gas%20Related%20Problems%20related%20to%20Spacesuits%20Dec%202022_Final.pdf
- Radiation protection technical brief (600 mSv career, 250 mSv SPE): https://www.nasa.gov/wp-content/uploads/2023/03/radiation-protection-technical-brief-ochmo.pdf
- Candidate real data: NASA OSDR search API, DONKI SEP API, NASA Life Sciences Data Archive, NTRS API, Curiosity RAD (listed by the independent Space Data Atlas; **suggestions, not the official resource list** — check the challenge page).

> **Verify before citing SMAC:** a later JSC 20584 revision states that CO₂ SMACs were deleted and CO₂ is managed through performance/health-based limits (https://www.nasa.gov/wp-content/uploads/2015/03/jsc_20584_signed.pdf). The SMAC numbers come from earlier literature.

## Results and limitations
On the 3-day synthetic set (3,456 rows, 4 crew; labels from the injected event phase): exact agreement 89.6 %, within one level 98.4 %,
CRITICAL rows detected 100 %, false alarms (≥ WARNING on calm rows) 1.8 %. On the supplied 20-row sample: 19/20 exact (the miss is a mild CAUTION at pCO₂ = 3.2 mmHg during exercise).
In the synthetic scenarios the first WARNING fires at event onset, and CRITICAL fires at the same time or up to 20 minutes before the label's CRITICAL band.

- Synthetic labels share their severity bands with the limits: this is a **self-consistency and robustness test** (noise, gaps, exercise/sleep false alarms), **not clinical validation**.
- Limits and context rules were tuned on the 20-row sample and the synthetic set; no independent real data was used.
- Radiation dose rate is simulated; the live DONKI panel shows real SEP events but they are not yet fed into the simulation.
- `pred_action` / `pred_why` texts are automatic suggestions written for this prototype, **not an official NASA procedure**.
- The dashboard UI was smoke-tested only with stubbed Streamlit/Altair in a sandbox; run `streamlit run app.py` locally before demo day.
